﻿----------------------------------------------------
-- Defines a simple AI in Lua for demo purposes ;)
----------------------------------------------------


-- defines some constants.. which will be upvalues everywhere.
local X = 1
local O = 2
local N = 0

-- checks if three pieces are a tris
function isTris(x, y, z)
	return (x ~= N) and (x == y) and (y == z);
end

-- checks if someone wins on the board
function isWin(board)
	for x = 1, 3 do
		if (isTris(board[x][1], board[x][2], board[x][3])) then
			return true;
		end
		if (isTris(board[1][x], board[2][x], board[3][x])) then
			return true;
		end
	end
	
	if (isTris(board[1][1], board[2][2], board[3][3]) ) then
		return true;
	end

	if (isTris(board[3][1], board[2][2], board[1][3]) ) then
		return true;
	end
end

-- creates a copy of a board
function copyBoard(board)
	local t = { {}, {}, {} }
	
	for x = 1, 3 do
		for y = 1, 3 do
			t[x][y] = board[x][y];
		end
	end
	
	return t;
end

-- checks if someone will win by putting the piece in the specified
-- position of the board
function willWinPuttingPiece(board, piece, x, y)
	if (board[x][y] ~= N) then
		return false;
	end

	local b = copyBoard(board);

	b[x][y] = piece;
	
	return isWin(b);
end

function printBoard(board)
	local chrs = { "-", "X", "O", err = "?" }
	local s = ""
	
	for x = 1, 3 do
		for y = 1, 3 do
			local x = board[x][y] + 1;
			
			if (x == nil or chrs[x] == nil) then x = "err"; end
		
			s = s .. chrs[x];
		end
		s = s .. "|";
	end
	
	print(s);
end


-- board is a table of 3 rows
-- does the play and returns x,y of the next move
-- prereq: we know the board is not won and is not full yet
function doPlay(board)

	printBoard(board);

	-- if I win putting piece in x,y... do it
	for x = 1, 3 do
		for y = 1, 3 do
			if willWinPuttingPiece(board, O, x, y) then
				print("Putting to win:", x, y);
				return x, y;
			end
		end
	end

	-- if I block a win... do it.
	for x = 1, 3 do
		for y = 1, 3 do
			if willWinPuttingPiece(board, X, x, y) then
				print("Putting to avoid losing:", x, y);
				return x, y;
			end
		end
	end

	-- go random!
	local possibilities = { };
	
	for x = 1, 3 do
		for y = 1, 3 do
			if board[x][y] == N then
				table.insert(possibilities, { x = x, y = y });
			end
		end
	end
	
	local idx = math.random(#possibilities)
	local x, y = possibilities[idx].x, possibilities[idx].y
	
	print("Putting at random", x, y)
	return x, y
end






