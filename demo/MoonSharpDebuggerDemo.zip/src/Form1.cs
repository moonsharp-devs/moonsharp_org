﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MoonSharp.Interpreter;
using MoonSharp.RemoteDebugger;

namespace MoonSharpLittleDemo
{
	public partial class Form1 : Form
	{
		char[,] m_Model = new char[3, 3];

		Script m_Script;
		RemoteDebuggerService m_Debug;
		Func<Table, DynValue> m_AiCode; 
		char m_Winner = '\0';

		 
		public Form1()
		{
			InitializeComponent();
		}

		private void Form1_Load(object sender, EventArgs e)
		{
			try
			{
			m_Script = new Script();
			m_Script.DoFile("AI.lua");

			var fn = m_Script.Globals.Get("doPlay").Function;

			m_AiCode = t => fn.Call(DynValue.NewTable(t));

			m_Script.DebugPrint = s => lstPrints.Items.Insert(0, s);

			btnRestart.PerformClick();
			}
			catch (ScriptRuntimeException ex)
			{
				MessageBox.Show(this, ex.DecoratedMessage, "Script error");
			}
			catch (SyntaxErrorException ex2)
			{
				MessageBox.Show(this, ex2.Message, "Syntax error");
			}
		}

		private void btnRestart_Click(object sender, EventArgs e)
		{
			for (int x = 0; x < 3; x++)
				for (int y = 0; y < 3; y++)
					m_Model[x, y] = ' ';

			m_Winner = '\0';

			RefreshButtons();
		}

		private void DoAIPlay()
		{
			try
			{
				Table board = CreateBoard();

				DynValue v = m_AiCode(board);

				int x = (int)v.Tuple[0].Number;
				int y = (int)v.Tuple[1].Number;

				m_Model[x - 1, y - 1] = 'O';

				RefreshButtons();
			}
			catch (ScriptRuntimeException ex)
			{
				MessageBox.Show(this, ex.DecoratedMessage, "Script error");
			}
		}

		private Table CreateBoard()
		{
			Table T = new Table(m_Script);
			T[1] = new Table(m_Script);
			T[2] = new Table(m_Script);
			T[3] = new Table(m_Script);

			for(int x= 0; x < 3; x++)
				for (int y = 0; y < 3; y++)
				{
					T.Get(x+1).Table.Set(y+1, DynValue.NewNumber(TranslateBoard(m_Model[x, y])));
				}

			return T;
		}

		private int TranslateBoard(char p)
		{
			if (p == ' ') return 0;
			if (p == 'X') return 1;
			if (p == 'O') return 2;
			throw new ArgumentException("p");
		}




		private void RefreshButtons()
		{
			UpdateButton(tileA1, 0, 0);
			UpdateButton(tileB1, 1, 0);
			UpdateButton(tileC1, 2, 0);
			UpdateButton(tileA2, 0, 1);
			UpdateButton(tileB2, 1, 1);
			UpdateButton(tileC2, 2, 1);
			UpdateButton(tileA3, 0, 2);
			UpdateButton(tileB3, 1, 2);
			UpdateButton(tileC3, 2, 2);
		}

		private void UpdateButton(Button btn, int x, int y)
		{
			btn.Enabled = m_Model[x, y] == ' ';
			btn.Text = m_Model[x, y].ToString();
		}

		private void CheckWin()
		{
			for (int i = 0; i < 3; i++)
			{
				if (IsTris(m_Model[i, 0], m_Model[i, 1], m_Model[i, 2]))
					GrantWin(m_Model[i, 0]);
				if (IsTris(m_Model[0, i], m_Model[1, i], m_Model[2, i]))
					GrantWin(m_Model[0, i]);
			}

			if (IsTris(m_Model[0, 0], m_Model[1, 1], m_Model[2, 2]))
				GrantWin(m_Model[0, 0]);

			if (IsTris(m_Model[2, 0], m_Model[1, 1], m_Model[0, 2]))
				GrantWin(m_Model[2, 0]);

			bool spacefound = false;

			for (int x = 0; x < 3; x++)
				for (int y = 0; y < 3; y++)
					if (m_Model[x, y] == ' ')
					{
						spacefound = true;
						break;
					}

			if (!spacefound)
				GrantWin(' ');
		}

		private bool IsTris(char p1, char p2, char p3)
		{
			return (p1 != ' ' && p1 == p2 && p2 == p3);
		}


		private void GrantWin(char p)
		{
			// Ugly workaround for Windows.Forms not refreshing the last button.
			// It's a frigging demo! Won't care.
			m_Winner = p;
			timer1.Start();
		}




		private void PlayOn(int x, int y)
		{
			m_Model[x, y] = 'X';
			RefreshButtons();

			CheckWin();

			if (m_Winner == '\0')
			{
				DoAIPlay();
				CheckWin();
			}
		}

		#region Button handlers

		private void tileA1_Click(object sender, EventArgs e)
		{
			PlayOn(0, 0);
		}

		private void tileB1_Click(object sender, EventArgs e)
		{
			PlayOn(1, 0);
		}

		private void tileC1_Click(object sender, EventArgs e)
		{
			PlayOn(2, 0);
		}

		private void tileA2_Click(object sender, EventArgs e)
		{
			PlayOn(0, 1);
		}

		private void tileB2_Click(object sender, EventArgs e)
		{
			PlayOn(1, 1);
		}

		private void tileC2_Click(object sender, EventArgs e)
		{
			PlayOn(2, 1);
		}

		private void tileA3_Click(object sender, EventArgs e)
		{
			PlayOn(0, 2);
		}

		private void tileB3_Click(object sender, EventArgs e)
		{
			PlayOn(1, 2);
		}

		private void tileC3_Click(object sender, EventArgs e)
		{
			PlayOn(2, 2);
		}

		#endregion

		private void timer1_Tick(object sender, EventArgs e)
		{
			timer1.Stop();

			if (m_Winner == 'O')
				MessageBox.Show(this, "Sorry, the computer won!");
			else if (m_Winner == 'X')
				MessageBox.Show(this, "Wow! You won!");
			else
				MessageBox.Show(this, "It's a draw.");

			btnRestart.PerformClick();

		}

		private void btnDebug_Click(object sender, EventArgs e)
		{
			if (m_Debug == null)
			{
				m_Debug = new RemoteDebuggerService();
				m_Debug.Attach(m_Script, "tic-tac-toe AI");
			}
			Process.Start(m_Debug.HttpUrlStringLocalHost);
		}


	}
}
