﻿namespace MoonSharpLittleDemo
{
	partial class Form1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
			this.tileA1 = new System.Windows.Forms.Button();
			this.tileB1 = new System.Windows.Forms.Button();
			this.tileC1 = new System.Windows.Forms.Button();
			this.tileA2 = new System.Windows.Forms.Button();
			this.tileB2 = new System.Windows.Forms.Button();
			this.tileC2 = new System.Windows.Forms.Button();
			this.tileA3 = new System.Windows.Forms.Button();
			this.tileB3 = new System.Windows.Forms.Button();
			this.tileC3 = new System.Windows.Forms.Button();
			this.btnRestart = new System.Windows.Forms.Button();
			this.btnDebug = new System.Windows.Forms.Button();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.timer1 = new System.Windows.Forms.Timer(this.components);
			this.lstPrints = new System.Windows.Forms.ListBox();
			this.SuspendLayout();
			// 
			// tileA1
			// 
			this.tileA1.Font = new System.Drawing.Font("Microsoft Sans Serif", 72F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.tileA1.Location = new System.Drawing.Point(46, 25);
			this.tileA1.Name = "tileA1";
			this.tileA1.Size = new System.Drawing.Size(135, 123);
			this.tileA1.TabIndex = 0;
			this.tileA1.Text = "X";
			this.tileA1.UseVisualStyleBackColor = true;
			this.tileA1.Click += new System.EventHandler(this.tileA1_Click);
			// 
			// tileB1
			// 
			this.tileB1.Font = new System.Drawing.Font("Microsoft Sans Serif", 72F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.tileB1.Location = new System.Drawing.Point(187, 25);
			this.tileB1.Name = "tileB1";
			this.tileB1.Size = new System.Drawing.Size(135, 123);
			this.tileB1.TabIndex = 0;
			this.tileB1.Text = "X";
			this.tileB1.UseVisualStyleBackColor = true;
			this.tileB1.Click += new System.EventHandler(this.tileB1_Click);
			// 
			// tileC1
			// 
			this.tileC1.Font = new System.Drawing.Font("Microsoft Sans Serif", 72F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.tileC1.Location = new System.Drawing.Point(328, 25);
			this.tileC1.Name = "tileC1";
			this.tileC1.Size = new System.Drawing.Size(135, 123);
			this.tileC1.TabIndex = 0;
			this.tileC1.Text = "X";
			this.tileC1.UseVisualStyleBackColor = true;
			this.tileC1.Click += new System.EventHandler(this.tileC1_Click);
			// 
			// tileA2
			// 
			this.tileA2.Font = new System.Drawing.Font("Microsoft Sans Serif", 72F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.tileA2.Location = new System.Drawing.Point(46, 154);
			this.tileA2.Name = "tileA2";
			this.tileA2.Size = new System.Drawing.Size(135, 123);
			this.tileA2.TabIndex = 0;
			this.tileA2.Text = "X";
			this.tileA2.UseVisualStyleBackColor = true;
			this.tileA2.Click += new System.EventHandler(this.tileA2_Click);
			// 
			// tileB2
			// 
			this.tileB2.Font = new System.Drawing.Font("Microsoft Sans Serif", 72F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.tileB2.Location = new System.Drawing.Point(187, 154);
			this.tileB2.Name = "tileB2";
			this.tileB2.Size = new System.Drawing.Size(135, 123);
			this.tileB2.TabIndex = 0;
			this.tileB2.Text = "X";
			this.tileB2.UseVisualStyleBackColor = true;
			this.tileB2.Click += new System.EventHandler(this.tileB2_Click);
			// 
			// tileC2
			// 
			this.tileC2.Font = new System.Drawing.Font("Microsoft Sans Serif", 72F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.tileC2.Location = new System.Drawing.Point(328, 154);
			this.tileC2.Name = "tileC2";
			this.tileC2.Size = new System.Drawing.Size(135, 123);
			this.tileC2.TabIndex = 0;
			this.tileC2.Text = "X";
			this.tileC2.UseVisualStyleBackColor = true;
			this.tileC2.Click += new System.EventHandler(this.tileC2_Click);
			// 
			// tileA3
			// 
			this.tileA3.Font = new System.Drawing.Font("Microsoft Sans Serif", 72F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.tileA3.Location = new System.Drawing.Point(46, 283);
			this.tileA3.Name = "tileA3";
			this.tileA3.Size = new System.Drawing.Size(135, 123);
			this.tileA3.TabIndex = 0;
			this.tileA3.Text = "X";
			this.tileA3.UseVisualStyleBackColor = true;
			this.tileA3.Click += new System.EventHandler(this.tileA3_Click);
			// 
			// tileB3
			// 
			this.tileB3.Font = new System.Drawing.Font("Microsoft Sans Serif", 72F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.tileB3.Location = new System.Drawing.Point(187, 283);
			this.tileB3.Name = "tileB3";
			this.tileB3.Size = new System.Drawing.Size(135, 123);
			this.tileB3.TabIndex = 0;
			this.tileB3.Text = "X";
			this.tileB3.UseVisualStyleBackColor = true;
			this.tileB3.Click += new System.EventHandler(this.tileB3_Click);
			// 
			// tileC3
			// 
			this.tileC3.Font = new System.Drawing.Font("Microsoft Sans Serif", 72F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.tileC3.Location = new System.Drawing.Point(328, 283);
			this.tileC3.Name = "tileC3";
			this.tileC3.Size = new System.Drawing.Size(135, 123);
			this.tileC3.TabIndex = 0;
			this.tileC3.Text = "X";
			this.tileC3.UseVisualStyleBackColor = true;
			this.tileC3.Click += new System.EventHandler(this.tileC3_Click);
			// 
			// btnRestart
			// 
			this.btnRestart.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnRestart.Location = new System.Drawing.Point(537, 45);
			this.btnRestart.Name = "btnRestart";
			this.btnRestart.Size = new System.Drawing.Size(103, 48);
			this.btnRestart.TabIndex = 1;
			this.btnRestart.Text = "Restart";
			this.btnRestart.UseVisualStyleBackColor = true;
			this.btnRestart.Click += new System.EventHandler(this.btnRestart_Click);
			// 
			// btnDebug
			// 
			this.btnDebug.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnDebug.Location = new System.Drawing.Point(537, 99);
			this.btnDebug.Name = "btnDebug";
			this.btnDebug.Size = new System.Drawing.Size(103, 48);
			this.btnDebug.TabIndex = 1;
			this.btnDebug.Text = "Debug!";
			this.btnDebug.UseVisualStyleBackColor = true;
			this.btnDebug.Click += new System.EventHandler(this.btnDebug_Click);
			// 
			// textBox1
			// 
			this.textBox1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox1.Location = new System.Drawing.Point(49, 423);
			this.textBox1.Multiline = true;
			this.textBox1.Name = "textBox1";
			this.textBox1.ReadOnly = true;
			this.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.textBox1.Size = new System.Drawing.Size(282, 147);
			this.textBox1.TabIndex = 2;
			this.textBox1.Text = resources.GetString("textBox1.Text");
			// 
			// timer1
			// 
			this.timer1.Interval = 1;
			this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
			// 
			// lstPrints
			// 
			this.lstPrints.FormattingEnabled = true;
			this.lstPrints.ImeMode = System.Windows.Forms.ImeMode.Off;
			this.lstPrints.IntegralHeight = false;
			this.lstPrints.Location = new System.Drawing.Point(346, 423);
			this.lstPrints.Name = "lstPrints";
			this.lstPrints.Size = new System.Drawing.Size(314, 147);
			this.lstPrints.TabIndex = 3;
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(691, 581);
			this.Controls.Add(this.lstPrints);
			this.Controls.Add(this.textBox1);
			this.Controls.Add(this.btnDebug);
			this.Controls.Add(this.btnRestart);
			this.Controls.Add(this.tileC3);
			this.Controls.Add(this.tileC2);
			this.Controls.Add(this.tileC1);
			this.Controls.Add(this.tileB3);
			this.Controls.Add(this.tileA3);
			this.Controls.Add(this.tileB2);
			this.Controls.Add(this.tileA2);
			this.Controls.Add(this.tileB1);
			this.Controls.Add(this.tileA1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximizeBox = false;
			this.Name = "Form1";
			this.Text = "MoonSharp Debugger Demo";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Button tileA1;
		private System.Windows.Forms.Button tileB1;
		private System.Windows.Forms.Button tileC1;
		private System.Windows.Forms.Button tileA2;
		private System.Windows.Forms.Button tileB2;
		private System.Windows.Forms.Button tileC2;
		private System.Windows.Forms.Button tileA3;
		private System.Windows.Forms.Button tileB3;
		private System.Windows.Forms.Button tileC3;
		private System.Windows.Forms.Button btnRestart;
		private System.Windows.Forms.Button btnDebug;
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.Timer timer1;
		private System.Windows.Forms.ListBox lstPrints;
	}
}

